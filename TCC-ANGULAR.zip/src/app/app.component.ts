import { Component } from '@angular/core';
import * as jwt_decode from 'jwt-decode';
import { UsuariosService } from './usuarios.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ProjetoAngular';

  constructor(
    private usuarioService: UsuariosService
  ){
    let token: any = localStorage.getItem('token');
    if(token){
      const decoded: any = jwt_decode.jwtDecode(token);
      let user = {
        login: decoded.sub
      }
      this.usuarioService.getUserByLogin(user).subscribe((data: any)=>{
        this.usuarioService.setUser({
          id: data.id,
          username: data.name,
          roles: data.role
        });
      });
    }

  }
}
