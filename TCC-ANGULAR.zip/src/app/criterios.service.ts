import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CriteriosService {

  private readonly API = 'api/criterios'

  constructor(private httpClient: HttpClient) {}


  salvarCriterios(dados: Partial<any>){
    return this.httpClient.post(this.API, dados);
   }

   listCriterios(){
    return this.httpClient.get(`${this.API}`);
  }

  editarCriterio(dados: Partial<any>){
    return this.httpClient.put(`${this.API}/${dados['id']}`, dados);
  }

  editarLista(dados: Partial<any>){
    return this.httpClient.put(`${this.API}/edit-list`, dados);
  }

  deleteById(id: any){
    return this.httpClient.delete(`${this.API}/${id}`);
  }

}
