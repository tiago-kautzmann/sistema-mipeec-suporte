import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { UsuariosService } from '../usuarios.service';
import * as jwt_decode from 'jwt-decode';
import { MatSelectModule } from '@angular/material/select';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {


  usuario: any;


  constructor(
    private router: Router,
    private authService: AuthService,
    private usuarioService: UsuariosService
  ){}


  verificaRota(){
    return this.router.url == '/'
  }

 async logout(){
   await this.authService.removeToken();
   await this.router.navigate(['login']);
  }

  minhaConta(){
    this.router.navigate(['/pagina-usuario/']);
  }


  hasPermission(role: string){
   return this.usuarioService.hasRole(role);
  }

}
