import { filter } from 'rxjs';
import { ProjetosService } from './../projetos.service';
import { Component, OnInit } from '@angular/core';
import { EventosService } from '../eventos.service';
import { FormBuilder } from '@angular/forms';
import { EnsinosService } from '../ensinos.service';
import { UsuariosService } from '../usuarios.service';
import * as jwt_decode from 'jwt-decode';
import { Router } from '@angular/router';
import { NotasService } from '../notas.service';

@Component({
  selector: 'app-escolher-projeto',
  templateUrl: './escolher-projeto.component.html',
  styleUrls: ['./escolher-projeto.component.scss']
})
export class EscolherProjetoComponent implements OnInit {

  constructor(
     private eventosService: EventosService,
      private fb: FormBuilder,
      private ensinoService: EnsinosService,
      private projetosService: ProjetosService,
      private usuarioService: UsuariosService,
      private router: Router,
      private notasService : NotasService,
  ){

  }

 eventos: any = [];
  areas: any = [];
  ensinos: any = [];
  data: any[] = [];
  listaProjetos: any = [];
  projetos: any = [];
  resumo: any = '';
  mostrarResumo: boolean = false;
  mostrarExcluir: boolean = false;
  dadosExcluir: any;
  projetosAvaliados: any = [];

    formfiltroAreas = this.fb.group({
    id: [null],
    area: [null],
    ativo: [null],
    // grupo: [null]
  });

    formfiltro = this.fb.group({
    id: [null],
    nome: [null],
    local: [null],
    dataInicial: [null],
    dataFinal: [null],
    ativo: [true],
    // area: [null]
  });



  ngOnInit(): void {
    this.getDados();
  }


  getDados(){
    let token: any = localStorage.getItem('token');
        const decoded: any = jwt_decode.jwtDecode(token);
        let user = {
          login: decoded.sub
        }

        this.usuarioService.getUserByLogin(user).subscribe((data: any)=>{

          this.getEventos();
          this.filtrarAreas();
          this.getEnsinos();
          this.getAvaliadoresProjetos(data);
        });
  }

  getAvaliadoresProjetos(usuario: any){
    this.projetos = [];
    this.projetosAvaliados = [];
    this.projetosService.getAvaliadoresProjetos().subscribe((projetosAvaliadores: any)=>{
        this.projetosService.getProjetos().subscribe((data: any)=>{
          let atribuidos = projetosAvaliadores.filter((x: any) => x.id_avaliador == usuario.id)
          data.forEach((projeto: any) => {
            this.notasService.getByIdProject(projeto.id).subscribe((notas: any)=>{
            let att = atribuidos.find((x: any) => x.id_projeto == projeto.id);
            let avaliado = notas.find((x: any) => x.avaliador == usuario.login);
            if(att && !avaliado){
              this.projetos.push(projeto);
            }else if(att && avaliado){
              this.projetosAvaliados.push(projeto);
            }
            });
          });
        });
    });

    }


  getEventos(){
    this.eventosService.filtro(this.formfiltro.value).subscribe((data: any)=>{
      this.eventos = data
    });
  }

  filtrarAreas(){
    this.eventosService.filtroAreas(this.formfiltroAreas.value).subscribe((data: any)=>{
      this.areas = data;
    });
  }

   getEnsinos(){
    this.ensinoService.list().subscribe((data: any)=>{
      this.ensinos = data;
    });
  }

  getList(evento: any, area: any, ensino: any){
    return this.projetos.filter((x: any) => x.id_evento == evento.id && x.id_area_conhecimento == area.id && x.ensino == ensino.ensino);
  }

  verResumo(resumo: any){
    this.resumo = resumo;
    this.gerenciaModalResumo();
  }

  gerenciaModalResumo(){
    this.mostrarResumo = !this.mostrarResumo;
  }

  gerenciaExcluirProjetos(){
    this.mostrarExcluir = !this.mostrarExcluir;
  }

  excluirProjetos(evento: any, area: any, ensino: any){
    this.dadosExcluir = {
      idEvento: evento.id,
      idArea: area.id,
      ensino: ensino.ensino
    }

    this.gerenciaExcluirProjetos();
  }

  lancarNota(id: any){
    this.router.navigate(['/lancar-notas//',  id]);
  }
}
