import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EscolherProjetoComponent } from './escolher-projeto.component';

describe('EscolherProjetoComponent', () => {
  let component: EscolherProjetoComponent;
  let fixture: ComponentFixture<EscolherProjetoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EscolherProjetoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EscolherProjetoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
