import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UsuariosService {

  private readonly API = 'api/usuario';
  public usuario: any;

  private userSubject: BehaviorSubject<any>;
  public user: Observable<any>;

  constructor(private httpClient: HttpClient) {
    this.userSubject = new BehaviorSubject<any>(null);
    this.user = this.userSubject.asObservable();
  }


  list(){
    return this.httpClient.get(`${this.API}`);
  }

  editarUsuario(dados: Partial<any>){
    return this.httpClient.put(`${this.API}/${dados['id']}`, dados);
  }

  getById(id: any){
    return this.httpClient.get(`${this.API}/${id}`);
  }

  deleteById(id: any){
    return this.httpClient.delete(`${this.API}/${id}`);
  }

  filtro(dados: Partial<any>){
    return this.httpClient.post(`${this.API}/filtro`, dados);
   }

   getUserByLogin(dados: Partial<any>){
    return this.httpClient.post(`${this.API}/by-login`, dados);
   }

   setUser(user: any): void {
    this.userSubject.next(user);
  }

  getUser(): any {
    return this.userSubject.value;
  }

  hasRole(role: string): boolean {
    const user = this.getUser();
    return user && user.roles.includes(role);
  }
}
