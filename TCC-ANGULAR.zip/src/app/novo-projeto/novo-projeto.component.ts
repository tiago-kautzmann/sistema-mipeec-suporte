import { AuthService } from './../auth.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { EventosService } from '../eventos.service';
import { param } from 'jquery';
import { AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { ProjetosService } from '../projetos.service';
import * as $ from 'jquery';
import { EnsinosService } from '../ensinos.service';

@Component({
  selector: 'app-novo-projeto',
  templateUrl: './novo-projeto.component.html',
  styleUrls: ['./novo-projeto.component.scss']
})
export class NovoProjetoComponent implements OnInit {

  evento: any = {};


  fileContent: any;
  fileName: string | undefined;

  idEvento: number = 0;

  ensinos: Array<any> = [];

  usuario: any = this.authService.getDataToken().sub;

  formProjeto = this.fb.group({
    titulo: [null, Validators.required],
    resumo: [null],
    nome_instituicao: [null, Validators.required],
    nome_responsavel: [null, Validators.required],
    url_anexo: null,
    nome_anexo: null,
    id_evento: [null, Validators.required],
    usuario: [this.usuario, Validators.required],
    base64: [null],
    file_name: [null],
    aceito: [false],
    ensino: [null, Validators.required],
    nome_evento: [null, Validators.required]
  });

  constructor(
    private eventosService: EventosService,
     private router: Router,
     private route: ActivatedRoute,
     private fb: FormBuilder,
     private projetosService: ProjetosService,
     private ensinoService: EnsinosService,
     private authService: AuthService
    ){

  }

  ngOnInit(): void {
    this.route.params.subscribe(params =>{
      this.getEvento(params['id']);
      this.fpj.id_evento.setValue(params['id']);
      this.idEvento = params['id'];
      this.getEnsinos();
    })
  }

  getEvento(id: any){

    this.eventosService.getById(id).subscribe((data: any)=>{
      this.fpj.nome_evento.setValue(data.nome);
      this.evento = data;
  })
  }

  getEnsinos(){
    this.ensinoService.list().subscribe((data: any)=>{
      this.ensinos = data;
    });
  }

  salvar(){
    this.projetosService.salvarProjeto(this.formProjeto.value).subscribe((data: any)=>{
      if(data){
        this.router.navigate(['cadastrar-projetos'])
      }
    })
  }

  limpar(){
    this.fpj['titulo'].setValue(null);
    this.fpj['nome_instituicao'].setValue(null);
    this.fpj['nome_responsavel'].setValue(null);
    this.fpj['resumo'].setValue(null);
  }

  get fpj (){
    return this.formProjeto.controls;
  }


  invalid(ctrl: AbstractControl){
    return ctrl.errors;
  }


  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      let file_name: any = file.name;
      this.fpj.file_name.setValue(file_name);
      const reader = new FileReader();

      reader.onload = (e: ProgressEvent<FileReader>) => {
        let base64: any = (e.target?.result as string).split(',')[1];
        this.fpj.base64.setValue(base64);
      };

      reader.readAsDataURL(file);
    }
  }

  excluirAnexo(){
    this.fpj['base64'].setValue(null);
    this.fpj['file_name'].setValue(null);

    $('#inputFile').val('');
  }

}
