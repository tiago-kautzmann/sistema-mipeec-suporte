import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmailService {

  private readonly API = 'api/email'

  constructor(private httpClient: HttpClient) { }


  sendEmail(dados: Partial<any>){
    return this.httpClient.post(this.API, dados);
   }
}
