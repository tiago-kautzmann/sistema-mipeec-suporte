import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RankingProjetosComponent } from './ranking-projetos.component';

describe('RankingProjetosComponent', () => {
  let component: RankingProjetosComponent;
  let fixture: ComponentFixture<RankingProjetosComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RankingProjetosComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RankingProjetosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
