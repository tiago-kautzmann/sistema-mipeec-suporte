import { filter } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { NotasService } from './../notas.service';
import { Component, OnInit } from '@angular/core';
import { data, map } from 'jquery';
import { ProjetosService } from '../projetos.service';
import { EnsinosService } from '../ensinos.service';

@Component({
  selector: 'app-ranking-projetos',
  templateUrl: './ranking-projetos.component.html',
  styleUrls: ['./ranking-projetos.component.scss']
})
export class RankingProjetosComponent implements OnInit {

  projetos: any = [];
  notas: any = [];
  lista: any = [];

  constructor(
    private notasService : NotasService,
    private route: ActivatedRoute,
    private projetosService: ProjetosService,
    private ensinosService: EnsinosService
  ){

  }

ngOnInit(): void {
  this.route.params.subscribe(params =>{

    this.projetosService.getProjetosByEvento(params['id']).subscribe((projeto: any)=>{
      this.notasService.getByIdEvent(params['id']).subscribe((notas: any)=>{

        projeto.forEach((element: any) => {
            let lista = notas.filter((x: any) => x.id_projeto == element.id);
            const avaliadoresUnicos = new Set(lista.map((a: any) => a.avaliador));

            if(lista.length > 0){
              this.projetos.push({"titulo": element.titulo,
                'nome_responsavel': element.nome_responsavel,
                "grupo": lista[0].grupo_criterio,
                "nota":
                (lista
                .map((x:any) => x.nota)
                .reduce((total: any, nota: any) => total + nota, 0) / avaliadoresUnicos.size).toFixed(1), "instituicao": element.nome_instituicao, 'ensino': element.ensino});
            }
        });

        this.ensinosService.list().subscribe((ensinos: any)=>{

          ensinos.forEach((en: any) => {
            let projetosDivididos = this.projetos.filter((x: any) => x.ensino == en.ensino);
            let grupos: any = Array.from(new Set(projetosDivididos.map((x: any) => x.grupo)));

            if(projetosDivididos.length > 0){
              let list: any = [];
              grupos.forEach((grupo: any) => {
                list.push({'grupo': grupo, 'projetos': projetosDivididos.filter((x: any) => x.grupo == grupo)});
              });
              this.lista.push({'ensino': en.ensino, 'grupos': list});

              this.lista[this.lista.length - 1].grupos.forEach((p: any) => {
                p.projetos.sort((a: any, b: any) => b.nota - a.nota);
              });

              // this.lista[this.lista.length - 1].projetos.sort((a: any, b: any) => b.nota - a.nota);
            }
          });
        });
          // this.projetos = this.projetos.sort((a: any, b: any) => b.nota - a.nota);
      });
    });

  });
}

changeTab(event: any){

}


}
