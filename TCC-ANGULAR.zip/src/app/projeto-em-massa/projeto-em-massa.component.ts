import { filter } from 'rxjs';
import { data, error } from 'jquery';
import { Component, OnInit } from '@angular/core';
import { EventosService } from '../eventos.service';
import { FormBuilder } from '@angular/forms';
import { EnsinosService } from '../ensinos.service';

import * as XLSX from 'xlsx';
import { ProjetosService } from '../projetos.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-projeto-em-massa',
  templateUrl: './projeto-em-massa.component.html',
  styleUrls: ['./projeto-em-massa.component.scss']
})
export class ProjetoEmMassaComponent  implements OnInit {


  constructor(
    private eventosService: EventosService,
    private fb: FormBuilder,
    private ensinoService: EnsinosService,
    private projetosService: ProjetosService,
    private router: Router,
  ){

  }

  eventos: any = [];
  areas: any = [];
  ensinos: any = [];
  data: any[] = [];
  listaProjetos: any = [];
  projetos: any = [];
  resumo: any = '';
  mostrarResumo: boolean = false;
  mostrarExcluir: boolean = false;
  dadosExcluir: any;
  idProjetoExcluir: number = 0;
  mostrarExcluirProjeto: boolean = false;

    formfiltroAreas = this.fb.group({
    id: [null],
    area: [null],
    ativo: [null],
    // grupo: [null]
  });

    formfiltro = this.fb.group({
    id: [null],
    nome: [null],
    local: [null],
    dataInicial: [null],
    dataFinal: [null],
    ativo: [true],
    // area: [null]
  });



  ngOnInit(): void {
    this.getEventos();
    this.filtrarAreas();
    this.getEnsinos();
    this.getProjetos();
  }


  getEventos(){
    this.eventosService.filtro(this.formfiltro.value).subscribe((data: any)=>{
      this.eventos = data
    });
  }

  filtrarAreas(){
    this.eventosService.filtroAreas(this.formfiltroAreas.value).subscribe((data: any)=>{
      this.areas = data;
    });
  }

   getEnsinos(){
    this.ensinoService.list().subscribe((data: any)=>{
      this.ensinos = data;
    });
  }

    getProjetos(){
      this.projetosService.getProjetos().subscribe((data: any)=>{
        this.projetos = data;
      });
    }

    onFileChange(event: any, item:any, area: any, ensino: any) {
      const file = event.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e: any) => {
        const binaryStr = e.target.result;

        const workbook = XLSX.read(binaryStr, { type: 'binary' });

        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];


        let data: any =  XLSX.utils.sheet_to_json(sheet);
        event.target.value = "";
        this.salvarProjetos(data, item, area, ensino);
      };

    reader.readAsBinaryString(file);
  }

  salvarProjetos(data: any, evento: any, area: any, ensino: any){
      let list: any = [];

      data.forEach((element: any) => {
        let projeto = {
          titulo: element['titulo'],
          resumo: element['resumo'],
          nome_instituicao: element['nome_instituicao'],
          nome_responsavel: element['nome_responsavel'],
          url_anexo: null,
          nome_anexo: null,
          id_evento: evento.id,
          usuario: null,
          base64: null,
          file_name: null,
          aceito: false,
          ensino: ensino.ensino,
          nome_evento: evento.nome,
          id_area_conhecimento: area.id
      }

        list.push(projeto);
      });

    this.projetosService.salvarProjetos(list).subscribe((data: any)=>{
      this.getProjetos();
    })
  }


  getList(evento: any, area: any, ensino: any){
    return this.projetos.filter((x: any) => x.id_evento == evento.id && x.id_area_conhecimento == area.id && x.ensino == ensino.ensino);
  }

  verResumo(resumo: any){
    this.resumo = resumo;
    this.gerenciaModalResumo();
  }

  gerenciaModalResumo(){
    this.mostrarResumo = !this.mostrarResumo;
  }

  gerenciaExcluirProjetos(){
    this.mostrarExcluir = !this.mostrarExcluir;
  }

  excluirProjetos(evento: any, area: any, ensino: any){
    this.dadosExcluir = {
      idEvento: evento.id,
      idArea: area.id,
      ensino: ensino.ensino
    }

    this.gerenciaExcluirProjetos();
  }

  confirmarExcluir(){
    this.projetosService.deletarProjetos(this.dadosExcluir).subscribe((data)=>{
      this.getProjetos();
    });
  }


  verRanking(item: any){
    this.router.navigate(['/ranking-projetos/', item.id]);
  }

  modalExcluirProjeto(){
    this.mostrarExcluirProjeto = !this.mostrarExcluirProjeto;
  }

  excluirProjeto(id: any){
    this.idProjetoExcluir = id;
    this.modalExcluirProjeto();
  }

  confirmarExcluirProjeto(){
    this.projetosService.excluirProjeto(this.idProjetoExcluir).subscribe((data: any)=>{
      this.getProjetos();
      this.modalExcluirProjeto();
    }, (error: any)=>{
    });
  }

}
