import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjetoEmMassaComponent } from './projeto-em-massa.component';

describe('ProjetoEmMassaComponent', () => {
  let component: ProjetoEmMassaComponent;
  let fixture: ComponentFixture<ProjetoEmMassaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProjetoEmMassaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProjetoEmMassaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
