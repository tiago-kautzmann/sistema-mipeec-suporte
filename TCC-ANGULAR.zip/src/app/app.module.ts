
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PrimeiroComponenteComponent } from './primeiro-componente/primeiro-componente.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { LancarNotasComponent } from './lancar-notas/lancar-notas.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatToolbarModule} from '@angular/material/toolbar';
import { ProjetosComponent } from './projetos/projetos.component';
import { CadastrarProjetosComponent } from './cadastrar-projetos/cadastrar-projetos.component';
import { NovoProjetoComponent } from './novo-projeto/novo-projeto.component';
import { CadastrarUsuariosComponent } from './cadastrar-usuarios/cadastrar-usuarios.component';
import { MatSelectModule } from '@angular/material/select';
import { HttpClientModule } from '@angular/common/http';
import { DialogComponent } from './dialog/dialog.component';
import { MatDialogModule } from '@angular/material/dialog';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { CadastrarEventosComponent } from './cadastrar-eventos/cadastrar-eventos.component';
import { EscolherProjetoComponent } from './escolher-projeto/escolher-projeto.component';
import { HomeComponent } from './home/home.component';
import { AuthenticationComponent } from './authentication/authentication.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { NewHomeComponent } from './new-home/new-home.component';
import { FooterComponent } from './footer/footer.component';
import { RankingProjetosComponent } from './ranking-projetos/ranking-projetos.component';
import { CriteriosComponent } from './criterios/criterios.component';
import { CollapseModule } from 'ngx-bootstrap/collapse';

import { httpInterceptorProviders } from './http-interceptor/';
import {MatTabsModule} from '@angular/material/tabs';


import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { PaginaUsuarioComponent } from './pagina-usuario/pagina-usuario.component';
import { AreasDoConhecimentoComponent } from './areas-do-conhecimento/areas-do-conhecimento.component';
import { ProjetoEmMassaComponent } from './projeto-em-massa/projeto-em-massa.component';

@NgModule({
  declarations: [
    AppComponent,
    PrimeiroComponenteComponent,
    LoginComponent,
    LancarNotasComponent,
    ProjetosComponent,
    CadastrarProjetosComponent,
    NovoProjetoComponent,
    CadastrarUsuariosComponent,
    DialogComponent,
    CadastrarEventosComponent,
    EscolherProjetoComponent,
    HomeComponent,
    AuthenticationComponent,
    CreateAccountComponent,
    NewHomeComponent,
    FooterComponent,
    RankingProjetosComponent,
    CriteriosComponent,
    PaginaUsuarioComponent,
    AreasDoConhecimentoComponent,
    ProjetoEmMassaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    BrowserAnimationsModule,
    MatToolbarModule,
    MatSelectModule,
    HttpClientModule,
    MatDialogModule,
    ReactiveFormsModule,
    MatSnackBarModule,
    CollapseModule.forRoot(),
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatTabsModule
  ],
  exports: [
    DialogComponent,
    MatDialogModule
  ],

  providers: [
    httpInterceptorProviders
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
