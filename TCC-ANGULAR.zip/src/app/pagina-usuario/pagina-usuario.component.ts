import { ProjetosService } from './../projetos.service';
import { Component, OnInit } from '@angular/core';
import * as jwt_decode from 'jwt-decode';
import { UsuariosService } from '../usuarios.service';
import { EventosService } from '../eventos.service';


@Component({
  selector: 'app-pagina-usuario',
  templateUrl: './pagina-usuario.component.html',
  styleUrls: ['./pagina-usuario.component.scss']
})
export class PaginaUsuarioComponent implements OnInit {


  constructor(
    private usuarioService: UsuariosService,
    private projetosService: ProjetosService,
    private eventosService: EventosService
  ){}

  usuario: any = {
    name: null,
  };

  projetos: any;
  projetoEscolhido: any;

  modalDetalhesProjeto: boolean = false;

  ngOnInit(): void {
    let token: any = localStorage.getItem('token');
    const decoded: any = jwt_decode.jwtDecode(token);
    let user = {
      login: decoded.sub
    }

    this.usuarioService.getUserByLogin(user).subscribe((data: any)=>{
      this.usuario = data;
      this.projetosService.getProjetosByUserLogin(user).subscribe((projetos: any)=>{
        this.projetos = projetos;
      });

    });
  }


  downloadPDF(base64String: string, fileName: any) {
    const byteCharacters = atob(base64String);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: 'application/pdf' });

    const blobUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = blobUrl;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(blobUrl);
  }

  verDetalhes(item: any){
    this.projetoEscolhido = item;
    this.gerenciaModalDetalhes();
  }



  gerenciaModalDetalhes(){
    this.modalDetalhesProjeto = !this.modalDetalhesProjeto;
  }

}
