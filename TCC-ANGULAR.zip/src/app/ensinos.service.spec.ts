import { TestBed } from '@angular/core/testing';

import { EnsinosService } from './ensinos.service';

describe('EnsinosService', () => {
  let service: EnsinosService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EnsinosService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
