import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


import * as jwt_decode from 'jwt-decode';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private readonly API = 'api/auth'

  constructor(private httpClient: HttpClient) { }


  register(dados: Partial<any>){
    return this.httpClient.post(this.API + '/register', dados);
   }

   login(dados: Partial<any>){
    return this.httpClient.post(this.API + '/login', dados);
   }

   getAuthorizationToken(){
    const token = window.localStorage.getItem('token');
    return token;
   }


   getTokenExpirationDate(token: string){
    const decoded: any = jwt_decode.jwtDecode(token);

    if(decoded.exp === undefined){
      return null;
    }

    const date = new Date(0);

    date.setUTCSeconds(decoded.exp);

    return date;

   }


   isTokenExpired(token?: string): boolean{
    if(!token){
      return true;
    }

    const date: any = this.getTokenExpirationDate(token);

    if(date === undefined){
      return false;
    }


    return !(date.valueOf() > new Date().valueOf())
   }


   isUserLoggedIn(){
    const token = this.getAuthorizationToken();

    if(!token){
      return false;
    }else if(this.isTokenExpired(token)){
      return false;
    }

    return true;
   }

   getDataToken(){
    const token: any = this.getAuthorizationToken();
    const decoded: any = jwt_decode.jwtDecode(token);

    return decoded;
   }


   removeToken(){
    localStorage.removeItem('token');
   }
}
