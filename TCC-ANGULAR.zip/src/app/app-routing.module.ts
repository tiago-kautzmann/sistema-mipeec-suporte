import { CadastrarUsuariosComponent } from './cadastrar-usuarios/cadastrar-usuarios.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PrimeiroComponenteComponent } from './primeiro-componente/primeiro-componente.component';
import { LoginComponent } from './login/login.component';
import { LancarNotasComponent } from './lancar-notas/lancar-notas.component';
import { CadastrarProjetosComponent } from './cadastrar-projetos/cadastrar-projetos.component';
import { ProjetosComponent } from './projetos/projetos.component';
import { NovoProjetoComponent } from './novo-projeto/novo-projeto.component';
import { CadastrarEventosComponent } from './cadastrar-eventos/cadastrar-eventos.component';
import { EscolherProjetoComponent } from './escolher-projeto/escolher-projeto.component';
import { HomeComponent } from './home/home.component';
import { AuthenticationComponent } from './authentication/authentication.component';
import { AuthGuard } from './auth.guard';
// import { CreateAccountComponent } from './create-account/create-account.component';
import { RankingProjetosComponent } from './ranking-projetos/ranking-projetos.component';
import { CriteriosComponent } from './criterios/criterios.component';
import { PaginaUsuarioComponent } from './pagina-usuario/pagina-usuario.component';
import { AreasDoConhecimentoComponent } from './areas-do-conhecimento/areas-do-conhecimento.component';
import { ProjetoEmMassaComponent } from './projeto-em-massa/projeto-em-massa.component';


const routes: Routes = [

  {path: '', component: HomeComponent,

  children: [
    {path: 'primeiro-componente', component: PrimeiroComponenteComponent},
    {path: 'lancar-notas/:id', component: LancarNotasComponent},
    {path: 'cadastrar-projetos', component: CadastrarProjetosComponent},
    {path: 'projetos-em-massa', component: ProjetoEmMassaComponent},
    {path: 'projetos', component: ProjetosComponent},
    {path: 'novo-projeto/:id', component: NovoProjetoComponent},
    {path: 'cadastrar-usuarios', component: CadastrarUsuariosComponent},
    {path: 'cadastrar-eventos', component: CadastrarEventosComponent},
    {path: 'escolher-projeto', component: EscolherProjetoComponent},
    {path: 'ranking-projetos/:id', component: RankingProjetosComponent},
    {path: 'criterios', component: CriteriosComponent},
    {path: 'pagina-usuario', component: PaginaUsuarioComponent},
    {path: 'areas-do-conhecimento', component: AreasDoConhecimentoComponent,}
  ],
  canActivate: [AuthGuard]
},


{path: '', component: AuthenticationComponent,

children: [
  {path: '', redirectTo: 'login', pathMatch: 'full'},
  {path: 'login', component: LoginComponent},
  // {path: 'create-account', component: CreateAccountComponent}
]
}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
