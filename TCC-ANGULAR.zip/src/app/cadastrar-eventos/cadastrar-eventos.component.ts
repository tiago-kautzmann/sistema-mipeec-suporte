import { Component, OnInit, ViewChild } from '@angular/core';
import { UsuariosService } from '../usuarios.service';
import { AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { EventosService } from '../eventos.service';
import { formatDate } from '@angular/common';
import * as $ from 'jquery';
import { CriteriosService } from '../criterios.service';

@Component({
  selector: 'app-cadastrar-eventos',
  templateUrl: './cadastrar-eventos.component.html',
  styleUrls: ['./cadastrar-eventos.component.scss']
})
export class CadastrarEventosComponent implements OnInit {

  constructor
   (private usuariosService: UsuariosService,
    private fb: FormBuilder,
    public dialog: MatDialog,
    private snackBar: MatSnackBar,
    private eventosService: EventosService,
    private criteriosService: CriteriosService
    ){}

  eventos: any = [];
  mostrar: boolean = false;
  mostrarEditar: boolean = false;
  mostrarDelete: boolean = false;
  id: any;
  grupos: any = [];
  areas: any = [];

  dataAtual = new Date();

  formfiltroAreas = this.fb.group({
    id: [null],
    area: [null],
    ativo: [null],
    // grupo: [null]
  });

  formAdicionar = this.fb.group({
    nome: [null, Validators.required],
    local: [null, Validators.required],
    dataInicial: [null, Validators.required],
    dataFinal: [null, Validators.required],
    momento_inclusao: formatDate(this.dataAtual, 'dd-mm-yyyy', 'en-US'),
    ativo: true,
    id_area: [null, Validators.required]
  });

  formEditar = this.fb.group({
    id: [null, Validators.required],
    nome: [null, Validators.required],
    local: [null, Validators.required],
    dataInicial: ['', Validators.required],
    dataFinal: ['', Validators.required],
    ativo: [null, Validators.required],
    id_area: [null, Validators.required]
  });


  formfiltro = this.fb.group({
    id: [null],
    nome: [null],
    local: [null],
    dataInicial: [null],
    dataFinal: [null],
    ativo: [null],
  });


  ngOnInit(){
    this.getEventos();
    this.list();
    this.filtrarAreas();
  }

  getEventos(){
    this.eventosService.list().subscribe((data: any)=>{
      this.eventos = data
    });
  }

  filtrarAreas(){
    this.eventosService.filtroAreas(this.formfiltroAreas.value).subscribe((data: any)=>{
      this.areas = data;
    });
  }

  adicionarEvento(){
    let dataInicial: any =  formatDate(new Date(), 'yyyy-MM-dd',  'en-US');
    let dataFinal: any =  formatDate(new Date().setDate(new Date().getDate() + 1), 'yyyy-MM-dd',  'en-US');
    this.fad.dataInicial.setValue(dataInicial);
    this.fad.dataFinal.setValue(dataFinal);
    this.mostrar = !this.mostrar;
  }

  fechar(){
    this.mostrar = !this.mostrar;
  }

  editarEvento(item: any){
    this.fedt.id.setValue(item.id);
    this.fedt.nome.setValue(item.nome);
    this.fedt.local.setValue(item.local);
    this.fedt.dataInicial.setValue(item.dataInicial);
    this.fedt.dataFinal.setValue(item.dataFinal);
    this.fedt.ativo.setValue(item.ativo);
    this.fedt.id_area.setValue(item.id_area)

    this.mostrarEditar = !this.mostrarEditar;
  }

  fecharEdicao(){
    this.mostrarEditar = !this.mostrarEditar;
  }

  confirmarAdicionar(){
    this.eventosService.salvarEvento(this.formAdicionar.value).subscribe((data: any)=>{
      if(data){
        this.getEventos();
        this.onSucess();
        this.fechar();
      }
    }, (error: any)=>{
      this.onError();
    });
  }

  onError(){
    this.snackBar.open('Erro ao salvar evento !', '', {duration: 3000});
  }

  onSucess(){
    this.snackBar.open('Evento Salvo com sucesso !', '', {duration: 3000});
  }

  limpar(){
    this.fad.local.setValue(null);
    this.fad.nome.setValue(null);
    this.fad.dataInicial.setValue(null);
    this.fad.dataFinal.setValue(null);
  }

  invalidForm(ctrl: AbstractControl){
    return ctrl.errors;
  }


  confirmarEdicao(){
    this.eventosService.editarEvento(this.formEditar.value).subscribe((data: any)=>{
      if(data){
        this.getEventos();
        this.fecharEdicao();
      }
    })
  }


  get fad (){
    return this.formAdicionar.controls;
  }

  get fedt(){
    return this.formEditar.controls;
  }

  get ff(){
    return this.formfiltro.controls;
  }

  filtrar(){
    this.eventosService.filtro(this.formfiltro.value).subscribe((data: any)=>{
      this.eventos = data;
    });
  }

  limparFiltro(){
    this.formfiltro.reset();
  }

  fecharDelete(){
    this.mostrarDelete = !this.mostrarDelete;
  }

  deletarEvento(id: any){
    this.mostrarDelete = !this.mostrarDelete;
    this.id = id;
  }


  confirmarDelete(){
    this.eventosService.deleteById(this.id).subscribe((data: any)=>{
      this.getEventos();
      this.mostrarDelete = !this.mostrarDelete;
    }, (error) =>{

    })
  }

  booleanIcon(value: boolean){
    return value ? 'fa fa-check' : 'fa fa-times'
  }

  list(){
    this.grupos = [];
    this.criteriosService.listCriterios().subscribe((data: any)=>{
      data.forEach((element: any) => {
        let adicionado = this.grupos.find((x: any) => x.nome == element.grupo);
        if(!adicionado){
          this.grupos.push({'id': element.id, 'nome': element.grupo, 'criterios': data.filter((x: any) => x.grupo == element.grupo)});
        }
      });

    });
  }

}
