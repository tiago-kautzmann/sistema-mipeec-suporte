import { Router } from '@angular/router';
import { EventosService } from './../eventos.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cadastrar-projetos',
  templateUrl: './cadastrar-projetos.component.html',
  styleUrls: ['./cadastrar-projetos.component.scss']
})
export class CadastrarProjetosComponent implements OnInit {

  constructor(
    private eventosService : EventosService,
    private router: Router
  ){

  }

  eventos: any = [];

  ngOnInit(): void {
      this.getEventos();
  }


  getEventos(){
    this.eventosService.list().subscribe((data: any)=>{
      for(let i = 0; i < data.length; i++){
        if(data[i].ativo){
          this.eventos.push(data[i]);
        }
      }
      // this.eventos = data;
    })
  }


  redireciona(id: any){
    this.router.navigate(['/novo-projeto/',  id]);
  }

}
