import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { UsuariosService } from '../usuarios.service';
import { AbstractControl, FormBuilder, Validators } from '@angular/forms';
import { emailValidator } from '../email.validator';
import { data } from 'jquery';
import { AuthService } from '../auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.scss']
})
export class CreateAccountComponent  implements OnInit{

  account = this.fb.group({
    login: [null, [Validators.required, emailValidator()]],
    name: [null, Validators.required],
    password: [null, Validators.required],
    password2: [null, Validators.required],
    role: ['USER', Validators.required],
  });

  erro: String = '';

  constructor(
    private usuarioService: UsuariosService,
    private fb: FormBuilder,
    private cdr: ChangeDetectorRef,
    private authService: AuthService,
    private snackBar: MatSnackBar,
  ){}

  ngOnInit(): void {
    this.cdr.detectChanges();
  }


  get fc (){
    return this.account.controls;
  }


  onSubmit(){
      if(this.fc.password.value != this.fc.password2.value){
        this.erro = 'Senhas incompatíveis'
      }else{

        let dados = {
          login: this.fc['login'].value,
          name: this.fc['name'].value,
          password: this.fc['password'].value,
          role: this.fc['role'].value,
        }

        this.authService.register(dados).subscribe((data: any)=>{
          window.open('http://localhost:4200/login');
        });
      }

  }


  isInvalid(campo: any){
    return !campo;
  }

  loginInValid(login: any){
    return !login.valid;
  }

  onError(){
    this.snackBar.open('Erro ao salvar evento !', '', {duration: 3000});
  }

  onSucess(){
    this.snackBar.open('Evento Salvo com sucesso !', '', {duration: 3000});
  }

}
