import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProjetosService {

  private readonly API = 'api/projetos'

  constructor(private httpClient: HttpClient) { }


  salvarProjeto(dados: Partial<any>){
    return this.httpClient.post(this.API, dados);
   }

  salvarProjetos(dados: Partial<any>){
    return this.httpClient.post(`${this.API}/salvar-projetos`, dados);
   }

   getProjetosByEvento(id: any){
    return this.httpClient.get(`${this.API}/evento/${id}`);
   }

   getProjetosById(id: any){
    return this.httpClient.get(`${this.API}/${id}`);
   }

   getProjetosByUserLogin(user: any){
    return this.httpClient.post(`${this.API}/projects-by-user`, user);
   }

   getProjetos(){
    return this.httpClient.get(`${this.API}/get-projetos`);
   }

  deletarProjetos(dados: any) {
    const opcoes = {
      body: dados
    };
   return this.httpClient.delete(`${this.API}/deletar-projetos`, opcoes);
  }

  salvarAvaliadoresProjetos(list: any){
    return this.httpClient.post(`${this.API}/salvar-lista-avaliadores`, list);
  }

  getAvaliadoresProjetos(){
    return this.httpClient.get(`${this.API}/get-avaliadores-projetos`);
   }

  deletarProjetosAvaliador(idAvaliador: any) {
   return this.httpClient.delete(`${this.API}/delete-por-avaliador/${idAvaliador}`);
  }

  excluirProjeto(id: any) {
    return this.httpClient.delete(`${this.API}/excluir-projeto/${id}`);
  }


}
