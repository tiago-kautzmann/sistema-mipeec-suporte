import { CriteriosService } from './../criterios.service';
import { Component, OnInit} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import * as $ from 'jquery';
import { filter } from 'rxjs';
import * as XLSX from 'xlsx';


@Component({
  selector: 'app-criterios',
  templateUrl: './criterios.component.html',
  styleUrls: ['./criterios.component.scss']
})
export class CriteriosComponent implements OnInit {
  criterios: any = [];
  isCollapsed: boolean = true;
  grupos: Array<any> = [];
  grupoEscolhido: any;
  mostrarCriterios: boolean = false;
  listaAdicionarCriterios: Array<any> = [];

  lac: Array<any> = [];
  listaAdicionarCriteriosGrupo: Array<any> = [];
  listaNotas: any = [];
  lan: Array<any> = [];

  lacg: Array<any> = [];
  listCriterios: Array<any> = [];
  lc: Array<any> = [];
  modalGrupoDuplicado: boolean = false;
  listaCriterios: boolean = false;
  modalDeletarCriterio: boolean = false;
  modalDeletarGrupo: boolean = false;
  modalAdicionarNotas: boolean = false;
  grupoDeletar: any;
  idDeletarCriterio: any;
  quantidadeNotas: number = 0;
  totalNotas: number = 0;
  totalEdit: number = 0;

  constructor(
    private fb: FormBuilder,
    private criteriosService: CriteriosService
  ) {}

  ngOnInit(): void {
    this.list();
    this.add();
  }

  booleanIcon(value: boolean) {
    return value ? 'fa fa-check' : 'fa fa-times';
  }

  verCriterios(item: any){
    this.grupoEscolhido = item;
    let total: number = 0;

    item.criterios.forEach((crit: any) => {
      if (crit.notas && crit.notas.length > 0) {
        const maiorNota = Math.max(...crit.notas.map((n: any) => Number(n.nota)));
        total += maiorNota;
      }
    });

    this.totalEdit = Number(total.toFixed(1));
    this.modalListaCriterios();
  }

    modalCriterios(){
      this.mostrarCriterios = !this.mostrarCriterios;
    }

    modalListaCriterios(){
      this.listaCriterios = !this.listaCriterios;
    }

    grupoDuplicado(){
      this.modalGrupoDuplicado = !this.modalGrupoDuplicado;
    }

    adicionarCriterios(){
      this.modalCriterios();
    }

  confirmarAdicionar(){

    let grupo = $('#inputAddGrupo').val();

    let invalid = this.grupos.find((x: any) => x.nome == grupo)

    if(invalid){
      this.grupoDuplicado();
      return;
    }

    let dados: any = [];
    this.listaAdicionarCriterios.forEach(element => {
        const notas = element.value.notas.map((x: any) => x.value.nota);

        const novoObj = {
          ...element.value,
          grupo: grupo,
          notas: notas
        };

        dados.push(novoObj);
      });

      this.criteriosService.salvarCriterios(dados).subscribe((data: any)=>{
        this.listaAdicionarCriterios = [];
        this.lac = [];
        this.listaNotas = [];
        this.modalCriterios();
        this.add();
        this.list();
      },  (error: any)=>{
    });
  }

  add(){

    let arrayNotas: any = [];

    if(this.listaNotas.length > 0){
      for(let i = 0; i < this.listaNotas.length; i++){

        let formNotas = this.fb.group({
          nota: [0]
        });

        arrayNotas.push(formNotas);
      }
    }else{
       let formNotas = this.fb.group({
          nota: [0]
        });

        this.listaNotas.push(formNotas);

        arrayNotas.push(formNotas);
    }

    let formCriterio = this.fb.group({
      nome: [null, Validators.required],
      notas: [arrayNotas]
    });

    this.lac.push(formCriterio.controls);

    this.listaAdicionarCriterios.push(formCriterio);
  }

  addNota(){

 let formNotas1 = this.fb.group({
        nota: [0]
      });

    this.lac.forEach(element => {
        let formNotas = this.fb.group({
        nota: [0]
      });

      element.notas.value.push(formNotas);
    });

    this.listaNotas.push(formNotas1);
  }


  addCriterioNoGrupo(id: any, value: any){

    if(value){
      let formCriterio = this.fb.group({
        id: [id],
        nome: [value ? value : null, Validators.required],
      });

      this.lc.push(formCriterio.controls);
      this.listCriterios.push(formCriterio);
    }else{

      let formCriterio = this.fb.group({
        nome: [value ? value : null, Validators.required],
      });

      this.lacg.push(formCriterio.controls);
      this.listaAdicionarCriteriosGrupo.push(formCriterio);
    }
  }

  excluirAdicionado(index: number){
    this.listaAdicionarCriteriosGrupo.splice(index, 1);
    this.lacg.splice(index, 1);
  }


  excluir(index: number){
    this.lac.splice(index, 1);
    this.listaAdicionarCriterios.splice(index, 1);
    this.calculaNotaTotal();
  }


  regraCadastrarCriterios(){
    let grupo = $('#inputAddGrupo').val();
    if(this.listaAdicionarCriterios.length < 1 || !grupo){
      return true
    }else{
      let invalid = this.listaAdicionarCriterios.find((x: any) => !x.valid);
      if(invalid){
        return invalid
      }else{
        let validation = false;
        this.lac.forEach(item => {
         let invalid2 = item.notas.value.find((x: any) => (!x.valid && x.value.nota !=0));
         if(invalid2){
          validation = true;
         }
      });

      return validation || this.totalNotas != 10;
      }
    }
  }

  list(){
    this.grupos = [];
    this.criteriosService.listCriterios().subscribe((data: any)=>{
      data.forEach((element: any) => {
        let adicionado = this.grupos.find((x: any) => x.nome == element.grupo);
        if(!adicionado){
          this.grupos.push({'id': element.id, 'nome': element.grupo, 'criterios': data.filter((x: any) => x.grupo == element.grupo)});
        }
      });
    });
  }

  confirmarEdicaoCriterios(){

    if(this.listaAdicionarCriteriosGrupo.length > 0){
      let dados: any = [];
      this.listaAdicionarCriteriosGrupo.forEach(element => {
        element.value.grupo = this.grupoEscolhido.nome;
        dados.push(element.value);
      });

      this.criteriosService.salvarCriterios(dados).subscribe((data: any)=>{
        this.list();
      });
    }

    this.listCriterios.forEach(element => {
      this.criteriosService.editarCriterio(element.value).subscribe((data: any)=>{
      });
    });

    this.modalListaCriterios();
    this.list();
  }

  deletarCriterio(){
    this.modalDeletarCriterio = !this.modalDeletarCriterio;
  }

  openDeletarCriterio(id: any, index: any){
    if(id){
         this.idDeletarCriterio = id;
         this.deletarCriterio();
    }else{
      this.grupoEscolhido.criterios.splice(index, 1);
    }
  }


  confirmarDeletarCriterio(){
    this.deletarCriterio();
    this.deletar(this.idDeletarCriterio);
    let index =  this.grupoEscolhido.criterios.findIndex((x: any) => x.id == this.idDeletarCriterio);
    this.grupoEscolhido.criterios.splice(index, 1);
  }


  openDeletarGrupo(grupo: any){
    this.grupoDeletar = grupo;
    this.deletarGrupo();
  }

  deletarGrupo(){
    this.modalDeletarGrupo = !this.modalDeletarGrupo;
  }

  confirmarDeletarGrupo(){
    this.deletarGrupo();
    this.grupoDeletar.criterios.forEach((element: any) => {
      this.deletar(element.id);
    });
  }


  deletar(id: any){
    this.criteriosService.deleteById(id).subscribe((data: any)=>{
      setTimeout(() => {
        this.list();
      }, 200);
    });
  }

  removerNota(){
    if(this.listaNotas.length > 1){
      this.lac.forEach(element => {
        element.notas.value.pop();
      });

      this.listaNotas.pop();
    }

    this.calculaNotaTotal();
  }


 calculaNotaTotal(){
  let total = 0;
  this.lac.forEach(element => {
    const notasNumericas = element.notas.value.map((obj: any) => obj.value.nota);
    const maiorNota = Math.max(...notasNumericas);
    total += maiorNota;
  });

  this.totalNotas = Number(total.toFixed(2));
}


   onFileChange(event: any) {
      const file = event.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e: any) => {
        const binaryStr = e.target.result;

        const workbook = XLSX.read(binaryStr, { type: 'binary' });

        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];

        let data: any =  XLSX.utils.sheet_to_json(sheet);
        event.target.value = "";
        this.salvarCriterios(data, sheetName);
      };

    reader.readAsBinaryString(file);
  }

  salvarCriterios(data: any, grupo: string){

    let dados: any = [];
    data.forEach((element: any) => {
      let keys = Object.keys(element);
      let notas: any = [];
      let criterio = element[keys[0]];

      for(let i = 1; i < keys.length; i++){
       notas.push(Number(element[keys[i]].replace(',','.')));
      }

      let obj = {
        nome: criterio,
        notas: notas,
        grupo: grupo
      }

      dados.push(obj);
    });

    this.criteriosService.salvarCriterios(dados).subscribe((data: any)=>{
        this.list();
      },  (error: any)=>{
    });
  }


  changeValue(nota: any, i: any, n: any){
    let input: any = Number($(`#nota-${i}-${n}`).val()).toFixed(1);
    if(input || input == 0){
      nota.nota = Number(input);
    }

    let total: number = 0;

    this.grupoEscolhido.criterios.forEach((crit: any) => {
      if (crit.notas && crit.notas.length > 0) {
        const maiorNota = Math.max(...crit.notas.map((n: any) => Number(n.nota)));
        total += maiorNota;
      }
    });

    this.totalEdit = Number(total.toFixed(1));
  }

  changeCrit(criterio: any, i: any){
    let input:any = $(`#crit-${i}`).val();

    if(input.trim()){
      criterio.nome = input;
    }
  }

  updateCriterios(){
    let array: any = [];

    this.grupoEscolhido.criterios.forEach((element: any) => {
      // if(!element.id){
      //   element.notas = element.notas.map((x: any) => x.nota);
      // }
      array.push(element);
    });

    this.criteriosService.editarLista(array).subscribe((data: any)=>{
          this.list();
          this.modalListaCriterios();
        },  (error: any)=>{
      });
  }

  addCriterioEdit(){
    let notas: any = [];

    this.grupoEscolhido.criterios[0].notas.forEach((element: any) => {
      notas.push({"nota": 0});
    });

    let obj = {
      nome: '',
      notas: notas,
      grupo: this.grupoEscolhido.nome
    }

    this.grupoEscolhido.criterios.push(obj);
  }

  ruleEdit(){

    let invalid = false;

    this.grupoEscolhido.criterios.forEach((crit: any) => {
      if(!crit.nome.trim()){
        invalid = true;
      }
    });


    return this.totalEdit != 10 || invalid;
  }

}
