import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { EventosService } from '../eventos.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CriteriosService } from '../criterios.service';

@Component({
  selector: 'app-areas-do-conhecimento',
  templateUrl: './areas-do-conhecimento.component.html',
  styleUrls: ['./areas-do-conhecimento.component.scss']
})
export class AreasDoConhecimentoComponent implements OnInit {


  formfiltro = this.fb.group({
    id: [null],
    area: [null],
    ativo: [null],
    // grupo: [null]
  });

  formAdicionar = this.fb.group({
      area: [null, Validators.required],
      ativo: [true, Validators.required],
      grupo: [null, Validators.required]
  });

    formEditar = this.fb.group({
      id: [null, Validators.required],
      area: [null, Validators.required],
      ativo: [true, Validators.required],
      grupo: [null, Validators.required]
  });


  mostrar: boolean = false;
  mostrarEditar: boolean = false;
  mostrarDelete: boolean = false;
  id: any;

  grupos: any = [];
  areas: any = [];

  constructor(
    private fb: FormBuilder,
    private eventosService: EventosService,
    private snackBar: MatSnackBar,
    private criteriosService: CriteriosService
  ){

  }

  get fedt(){
    return this.formEditar.controls;
  }


  ngOnInit(): void {
     this.filtrar();
     this.getCriterios();
  }


  filtrar(){
    this.eventosService.filtroAreas(this.formfiltro.value).subscribe((data: any)=>{
      this.areas = data;
    });
  }


  limparFiltro(){
    this.formfiltro.reset();
  }


  adicionarArea(){
    this.mostrar = !this.mostrar;
  }

  confirmarAdicionar(){
    this.eventosService.salvarArea(this.formAdicionar.value).subscribe((data: any)=>{
      if(data){
        this.filtrar();
        this.onSucess();
        this.fechar();
        this.limparAdicionar();
      }
    }, (error: any)=>{
      this.onError();
    });
  }

  booleanIcon(value: boolean){
    return value ? 'fa fa-check' : 'fa fa-times'
  }


  editarArea(item: any){
    this.fedt.id.setValue(item.id);
    this.fedt.ativo.setValue(item.ativo);
    this.fedt.area.setValue(item.area);
    this.fedt.grupo.setValue(item.grupo);
    this.mostrarEditar = !this.mostrarEditar;
  }

  deletarArea(id: any){
    this.mostrarDelete = !this.mostrarDelete;
    this.id = id;
  }


  fecharDelete(){
    this.mostrarDelete = !this.mostrarDelete;
  }

  confirmarDelete(){
    this.eventosService.deleteAreaById(this.id).subscribe((data: any)=>{
      this.filtrar();
      this.mostrarDelete = !this.mostrarDelete;
    });
  }

  onError(){
    this.snackBar.open('Erro ao salvar área !', '', {duration: 3000});
  }

  onSucess(){
    this.snackBar.open('Área Salvo com sucesso !', '', {duration: 3000});
  }

  fechar(){
    this.mostrar = !this.mostrar;
  }

  limparAdicionar(){
    this.formAdicionar.reset({ativo: true});
  }

  fecharEdicao(){
    this.mostrarEditar = !this.mostrarEditar;
  }


  confirmarEdicao(){
    this.eventosService.editarArea(this.formEditar.value).subscribe((data: any)=>{
      if(data){
        this.filtrar();
        this.fecharEdicao();
      }
    })
  }

  getCriterios(){
      this.grupos = [];
      this.criteriosService.listCriterios().subscribe((data: any)=>{
        data.forEach((element: any) => {
          let adicionado = this.grupos.find((x: any) => x.grupo == element.grupo);
          if(!adicionado){
            this.grupos.push({'id': element.id, 'grupo': element.grupo, 'criterios': data.filter((x: any) => x.grupo == element.grupo)});
          }
        });

      });
  }

  nomeGrupo(id: any){
   if(this.grupos.length > 0){
    return this.grupos.find((x: any) => x.grupo == id).grupo;
   }
  }

}
