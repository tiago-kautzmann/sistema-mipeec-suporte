import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AreasDoConhecimentoComponent } from './areas-do-conhecimento.component';

describe('AreasDoConhecimentoComponent', () => {
  let component: AreasDoConhecimentoComponent;
  let fixture: ComponentFixture<AreasDoConhecimentoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AreasDoConhecimentoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AreasDoConhecimentoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
