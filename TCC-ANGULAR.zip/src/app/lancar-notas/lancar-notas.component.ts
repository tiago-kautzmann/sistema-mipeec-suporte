import { filter } from 'rxjs';
import { UsuariosService } from './../usuarios.service';
import { Component, Input, OnInit } from '@angular/core';
import * as $ from 'jquery'
import { ProjetosService } from '../projetos.service';
import { ActivatedRoute, Router } from '@angular/router';
import { EventosService } from '../eventos.service';
import { NotasService } from '../notas.service';
import { CriteriosService } from '../criterios.service';

@Component({
  selector: 'app-lancar-notas',
  templateUrl: './lancar-notas.component.html',
  styleUrls: ['./lancar-notas.component.scss']
})
export class LancarNotasComponent implements OnInit {

  constructor(
    private projetosService: ProjetosService,
    private route: ActivatedRoute,
    private eventosService: EventosService,
    private notasService: NotasService,
    private criteriosService: CriteriosService,
    private usuarioService: UsuariosService,
    private router: Router,
    ){}

  criterios: any = [];
  notaFinal: any = 0;
  projeto: any = {};
  evento: any = {};
  desabilitaSalvar: boolean = false;
  notaTotal: any = 0;
  grupos: any = [];
  usuario: any;
  totalNotas: number = 0;
  listaNotas: any = [];
  modalCancelar: boolean = false;


  //   selected: { [criterioId: number]: number } = {};

  //   selectOption(criterioId: number, nota: number) {
  //   this.selected[criterioId] = nota;
  // }

  ngOnInit(): void {
    this.route.params.subscribe(params =>{
      this.getProjeto(params['id']);
    });

    setTimeout(() => {
      let user = this.usuarioService.getUser();
      this.usuarioService.getById(user.id).subscribe((data: any)=>{
        this.usuario = data;
      })
    }, 100);
  }

  areaById(id: any){
    let filtro = {
        id: id,
        area: null,
        ativo: null,
      };

    this.eventosService.filtroAreas(filtro).subscribe((data: any)=>{

    this.criteriosService.listCriterios().subscribe((dataCriterios: any)=>{
        dataCriterios.forEach((element: any) => {
          if(element.grupo == data[0].grupo){
            this.criterios.push({"nome": element.nome, "notas": element.notas, "grupo": element.grupo});
          }
        });
      });
    });
  }

  getProjeto(id: any){
    this.projetosService.getProjetosById(id).subscribe((data: any)=>{
      this.projeto = data;
      this.getEvento(data.id_evento);
      this.areaById(this.projeto.id_area_conhecimento);
    })
  }

  getEvento(id: any){
    this.eventosService.getById(id).subscribe((data: any)=>{
      this.evento = data;
    });
  }

  valorNotas(){
    let total = 0;

    for(let index = 0; index < this.criterios.length; index++){
      if($('#inputNota' + index).val() || $('#inputNota' + index).val() == 0){
        total += Number($('#inputNota' + index).val());
      }
    }

    this.notaFinal = total / this.criterios.length;
  }

  salvarNotas(){

    let dados: any = [];

    for(let i = 0; i< this.listaNotas.length; i++){
      dados.push({"criterio": this.criterios[i].nome, "nota": this.listaNotas[i].nota, "grupo_criterio": this.criterios[i].grupo,
       "id_evento": this.evento.id, "id_projeto": this.projeto.id, "avaliador":  this.usuario.login});
    }

    this.notasService.salvarNotas(dados).subscribe((data: any)=>{
        this.router.navigate(['/escolher-projeto']);
      });
  }

  changeNota(index: any){
    this.criterios[index].valor = $('#inputNota' + index).val();
  }

  verificaNotas(){
   let notNumber =  this.criterios.find((x: any) => isNaN(parseFloat(x.valor)));

   if(!notNumber){
    let invalido = this.criterios.find((x: any) => x.valor > 10 || x.valor < 0);
    if(!invalido){
      return true;
    }else{
      return false;
    }
   }else{
    return false;
   }
  }

  list(){
    this.grupos = [];
    this.criteriosService.listCriterios().subscribe((data: any)=>{
      data.forEach((element: any) => {
        let adicionado = this.grupos.find((x: any) => x.nome == element.grupo);
        if(!adicionado){
          this.grupos.push({'id': element.id, 'nome': element.grupo, 'criterios': data.filter((x: any) => x.grupo == element.grupo)});
        }
      });

    });
  }

  trackByNota(index: number, nota: any) {
  // devolve uma chave única para cada nota
  return nota.nota + '-' + index;
}


// divs: any = [];

// mudarCor(i: number, n: number){
//   let div = document.getElementById('nota-' + i + '-' + n);
//   div.style.backgroundColor = '#2563eb';
// }

  selected: { [criterioIndex: number]: number } = {};

  mudarCor(criterioIndex: number, notaIndex: number, nota: any, idCriterio: any) {
    this.selected[criterioIndex] = notaIndex;
    this.somaNotas(nota, idCriterio)
  }

  somaNotas(nota: any, indexCriterio: any){
    let item =  this.listaNotas.find((x: any)=> x.id == indexCriterio);

    if(item){
      item.nota = nota.nota;
    }else{
      this.listaNotas.push({'id': indexCriterio, 'nota': nota.nota});
    }

    this.totalNotas = this.listaNotas.reduce((total: number, item: any) => total + item.nota, 0).toFixed(1);
  }

  changeModalCancelar(){
    this.modalCancelar = !this.modalCancelar;
  }

  cancelar(){
    this.changeModalCancelar();
  }

  confirmarCancelar(){
    this.router.navigate(['/escolher-projeto']);
  }
}
