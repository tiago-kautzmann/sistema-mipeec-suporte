import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NotasService {

  private readonly API = 'api/notas'

  constructor(private httpClient: HttpClient) { }

  salvarNotas(dados: Partial<any>){
    return this.httpClient.post(this.API + '/salvar-notas', dados);
   }


   getById(id: any){
    return this.httpClient.get(`${this.API}/${id}`);
  }

  getByIdProject(idProject: any){
    return this.httpClient.get(`${this.API}/${idProject}`);
  }

  getByIdEvent(idEvento: any){
    return this.httpClient.get(`${this.API}/projetos/${idEvento}`);
  }

}
