import { AccountService } from './../account.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as $ from 'jquery';
import { UsuariosService } from '../usuarios.service';
import { EmailService } from '../email.service';
import { FormBuilder, Validators } from '@angular/forms';
import { emailValidator } from '../email.validator';
import { AuthService } from '../auth.service';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  account = this.fb.group({
    login: [null, Validators.required],
    password: [null, Validators.required]
  });

  usuario: any;

  usuarios: Array<any> = [];

  erro: String = '';
  erro2: String = '';
  erro3: String = '';
  codigo: String = '';

  modalEsqueceuSenha: boolean = false;
  recuperacao: boolean = false;
  novaSenha: boolean = false;

  constructor(
    private router: Router,
    private usuariosService: UsuariosService,
    private emailService: EmailService,
    private fb: FormBuilder,
    private authService: AuthService,
    private snackBar: MatSnackBar,
  ){}

  ngOnInit(): void {
    this.getUsuarios();
  }


  getUsuarios(){
    this.usuariosService.list().subscribe((data: any)=>{
      this.usuarios = data;
    });
  }

  onSubmit(){
    if(!this.account.valid){
      this.onError();
    }else{
      this.authService.login(this.account.value).subscribe((data: any)=>{
        if(data){
          this.onSucess();
          window.localStorage.setItem('token', data.token);
          this.usuariosService.getUserByLogin(this.account.value).subscribe((usuario: any)=>{

            this.usuariosService.setUser({
              id: usuario.id,
              username: usuario.name,
              roles: usuario.role
            });

            this.router.navigate(['']);
          });
        }
      }, (error)=>{
        this.onError();
      });
    }
  }


  gerenciaModalEsqueceuSenha(){
    this.recuperacao = false;
    this.erro = '';
    this.erro2 = '';
    this.erro2 = '';
    $('#inputEmailRecuperacao').val('');
    this.codigo = '';
    this.novaSenha = false;
    this.modalEsqueceuSenha = !this.modalEsqueceuSenha;
  }

  enviarCodigo(){

    let email: any = $('#inputEmailRecuperacao').val();
    this.codigo = '';

    if(!email.trim() && !this.verificaEmail(email)){
      this.erro = 'Email inválido!'
    }else{
      let existe = this.usuarios.find((x: any) => x.login == email);
      if(!existe){
        this.erro = 'Email não cadastrado!'
      }else{
        this.erro = '';
        let codigo = this.generateRandomCode();
        this.codigo = codigo;
        this.recuperacao = true;
        this.usuario = existe;
        let message = {
          "to": email,
          "subject": "Recuperação de senha MIPEEC",
          "body": `Seu código para recuperação é: ${codigo}`
      }

        this.emailService.sendEmail(message).subscribe((data: any)=>{});
      }
    }
  }


  verificaEmail(email: String){
    return email.includes('@');
  }


  generateRandomCode(): string {
    const length = 8;
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
  }

  verificarCodigo(){
    let codigo: any = $('#inputCodigo').val();
    this.novaSenha = false;
    if(codigo == this.codigo){
      this.erro2 = '';
      this.novaSenha = true;
    }else{
      this.erro2 = 'Código Inválido';
    }
  }

  salvarNovaSenha(){
    let senha1: any = $('#inputNovaSenha1').val();
    let senha2: any = $('#inputNovaSenha2').val();

    if(!senha1.trim() || !senha2.trim()){
      this.erro3 = 'Senha inválida'
    }else{
      if(senha1 != senha2){
        this.erro3 = 'Senhas incompatíveis'
      }else{

        let body = {
          id: this.usuario.id,
          name: this.usuario.name,
          role: this.usuario.role,
          login: this.usuario.login,
          password: senha1
        }

        this.usuariosService.editarUsuario(body).subscribe((data: any)=>{
          this.usuario = null;
          this.gerenciaModalEsqueceuSenha();
          this.getUsuarios();
        });
      }
    }

  }


  onError(){
    this.snackBar.open('Usuário ou senha incorretos !', '', {duration: 3000});
  }

  onSucess(){
    this.snackBar.open('Login efetuado com sucesso !', '', {duration: 3000});
  }

}
