import { filter } from 'rxjs';
import { Component, OnInit, ViewChild } from '@angular/core';
import * as $ from 'jquery';
import { UsuariosService } from '../usuarios.service';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { emailValidator } from '../email.validator';
import { AuthService } from '../auth.service';
import { ProjetosService } from '../projetos.service';
import { EventosService } from '../eventos.service';

@Component({
  selector: 'app-cadastrar-usuarios',
  templateUrl: './cadastrar-usuarios.component.html',
  styleUrls: ['./cadastrar-usuarios.component.scss']
})
export class CadastrarUsuariosComponent implements OnInit {

  users: any = [];
  mostrar: boolean = false;
  mostrarEditar: boolean = false;
  mostrarDelete: boolean = false;
  mudarSenha: boolean = false;
  id: any;
  mostrarAtribuicao: boolean = false;
  projetos: any = [];
  areas: any = [];
  user: any;

  @ViewChild('matPermission') matPermission: any;

  formAdicionar = this.fb.group({
    name: [null, Validators.required],
    role: [null, Validators.required],
    login: [null, [Validators.required, emailValidator()]],
    password: [null, Validators.required]
  });

  formEditar = this.fb.group({
    id: null,
    name: [null, Validators.required],
    role: [null, Validators.required],
    login: [null, Validators.required],
    password: [null, Validators.required]
  });


  formFiltro = this.fb.group({
    id: [null],
    name: [null],
    role: [null],
    login: [null],
  });

  formfiltroAreas = this.fb.group({
    id: [null],
    area: [null],
    ativo: [null],
    // grupo: [null]
  });

  resumo: any = '';
  mostrarResumo: boolean = false;


  constructor(
    private usuariosService: UsuariosService,
    private fb: FormBuilder,
    public dialog: MatDialog,
    private snackBar: MatSnackBar,
    private authService: AuthService,
    private projetosService: ProjetosService,
    private eventosService: EventosService,
    // private formGroup: FormGroup
  ){}

  ngOnInit(){
    this.getUsuarios();
    this.filtrarAreas();
    this.getProjetos();

  }

  getUsuarios(){
    this.usuariosService.list().subscribe((data: any)=>{
      this.users = data;
      this.getAvaliadoresProjetos(data);
    }, (error: any)=> {
    });
  }

  adicionarUsuario(){
    $('#input-login').val('');
    $('#input-senha').val('');
    this.formAdicionar.reset();
    this.mostrar = !this.mostrar;
  }

  fechar(){
    this.mostrar = !this.mostrar;
  }

  modalSenha(){
    this.mudarSenha = !this.mudarSenha;
  }

  editarUsuario(item: any){
    this.fedt.id.setValue(item.id);
    this.fedt.login.setValue(item.login);
    this.fedt.name.setValue(item.name);
    this.fedt.role.setValue(item.role);
    this.fedt.password.setValue(item.password);
    this.mostrarEditar = !this.mostrarEditar;
  }

  fecharEdicao(){
    this.mostrarEditar = !this.mostrarEditar;
  }

  confirmarAdicionar(){
    if(!this.formAdicionar.valid){
      this.onError('Erro ao salvar usuário !');
    }else{
      this.authService.register(this.formAdicionar.value).subscribe((data: any)=>{
        this.getUsuarios();
        this.onSucess('Usuário Salvo com sucesso !');
        this.fechar();
      }, (error: any)=>{
        this.onError('Erro ao salvar usuário !');
      });
    }
  }

  onError(texto: string){
    this.snackBar.open(texto, '', {duration: 3000});
  }

  onSucess(texto: string){
    this.snackBar.open(texto, '', {duration: 3000});
  }


  erroSenha(){
    this.snackBar.open('Erro ao mudar a senha!', '', {duration: 3000});
  }

  limparAdicionar(){
    this.formAdicionar.reset();
  }

  limparEdicao(){

  }


  invalidForm(ctrl: AbstractControl){
    return ctrl.errors;
  }


  confirmarEdicao(){
    this.usuariosService.editarUsuario(this.formEditar.value).subscribe((data: any)=>{
      if(data){
        this.getUsuarios();
        this.fecharEdicao();
      }
    })
  }


  get fad (){
    return this.formAdicionar.controls;
  }

  get fedt(){
    return this.formEditar.controls;
  }

  filtrar(){
    this.usuariosService.filtro(this.formFiltro.value).subscribe((data: any)=>{
      this.users = data;
    });
  }

  limparFiltro(){
    this.formFiltro.reset();
  }

  fecharDelete(){
    this.mostrarDelete = !this.mostrarDelete;
  }

  deletarUsuario(id: any){
    this.mostrarDelete = !this.mostrarDelete;
    this.id = id;
  }


  confirmarDelete(){
    this.usuariosService.deleteById(this.id).subscribe((data: any)=>{
      this.getUsuarios();
      this.mostrarDelete = !this.mostrarDelete;
    })
  }

  editarSenha(item: any){
    $('#senha1').val('');
     $('#senha2').val('');
    this.fedt.id.setValue(item.id);
    this.fedt.password.setValue(item.password);
    this.modalSenha();
  }


  regraSenha(){
   let senha1: any =  $('#senha1').val();
   let senha2: any =  $('#senha2').val();

   if(!senha1.trim() || !senha2.trim()){
    return true;
   }else{
    return !(senha1.trim() == senha2.trim());
   }
  }


  confirmarMudancaDeSenha(){
    let senha: any = $('#senha1').val();

    if(senha){
      this.fedt.password.setValue(senha);
      this.usuariosService.editarUsuario(this.formEditar.value).subscribe((data: any)=>{
        if(data){
          this.getUsuarios();
          this.modalSenha();
        }
      })
    }else{
      this.erroSenha();
    }
    }

    mostrarSenha(){
     let senha1 =  document.querySelector('#senha1');
     let senha2 =  document.querySelector('#senha2');

     if(senha1?.getAttribute('type') == 'password'){
      senha1?.setAttribute('type', 'text');
      senha2?.setAttribute('type', 'text');
     }else{
      senha1?.setAttribute('type', 'password');
      senha2?.setAttribute('type', 'password');
     }
    }

    gerenciaModalAtribuicao(){
      this.mostrarAtribuicao = !this.mostrarAtribuicao;
    }

    getProjetos(){
      this.projetosService.getProjetos().subscribe((data: any)=>{
        this.projetos = data;
      });
    }

   filtrarAreas(){
    this.eventosService.filtroAreas(this.formfiltroAreas.value).subscribe((data: any)=>{
      this.areas = data;
    });
  }


  getList(id: any){
    return this.projetos.filter((x: any) => x.id_area_conhecimento == id)
  }

    verResumo(resumo: any){
    this.resumo = resumo;
    this.gerenciaModalResumo();
  }

   gerenciaModalResumo(){
    this.mostrarResumo = !this.mostrarResumo;
  }

  modalAtribuicao(){
    this.mostrarAtribuicao = !this.mostrarAtribuicao;
  }

  atribuir(item: any){
    this.user = item;
    this.modalAtribuicao();
  }

  changeProject(event: any, projeto: any){
    if(event.target.checked){
      this.user.projetos.push({'id_avaliador': this.user.id, 'id_projeto': projeto.id})
    }else{
      let index =  this.user.projetos.findIndex((x: any) => x.id_projeto == projeto.id);
      this.user.projetos.splice(index, 1);
    }
  }

    mudaTodos(event: any, id_area: any) {
      if (event.target.checked) {
        const novos = this.projetos
          .filter((x: any) => x.id_area_conhecimento == id_area)
          .map((x: any) => ({
            id_avaliador: this.user.id,
            id_projeto: x.id
          }));

        // adiciona sem duplicar
        this.user.projetos = [
          ...this.user.projetos.filter(
            (p: any) => !novos.some((n: any) => n.id_projeto === p.id_projeto)
          ),
          ...novos
        ];
      } else {
        // remove os da área desmarcada
        this.user.projetos = this.user.projetos.filter((p: any) => {
          const projeto = this.projetos.find((x: any) => x.id === p.id_projeto);
          return projeto?.id_area_conhecimento !== id_area;
        });
      }

      // 🔒 Normaliza o formato para garantir consistência
      this.user.projetos = this.user.projetos.map((p: any) => ({
        id_avaliador: this.user.id,
        id_projeto: p.id_projeto ?? p.id // caso venha como {id: ...}
      }));
    }

    confirmarAtribuicao(){
      this.projetosService.deletarProjetosAvaliador(this.user.id).subscribe((deleted)=>{
            this.projetosService.salvarAvaliadoresProjetos(this.user.projetos).subscribe((data: any)=>{
             this.getUsuarios();
             this.modalAtribuicao();
          });
      })
    }

    getAvaliadoresProjetos(data: any){
      this.projetosService.getAvaliadoresProjetos().subscribe((projetosAvaliadores: any)=>{
         data.forEach((element: any) => {
          element.projetos = projetosAvaliadores.filter((x: any) => x.id_avaliador == element.id).map((p: any) => ({
            id_avaliador: p.id_avaliador,
            id_projeto: p.id_projeto // caso venha como {id: ...}
          }));
        });

      });
    }


    check(id: any){
     return this.user.projetos.find((x: any)=> x.id_projeto == id);
    }

}
