import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EventosService {
  private readonly API = 'api/eventos'

  constructor(private httpClient: HttpClient) { }

  list(){
    return this.httpClient.get(`${this.API}`);
  }

  getById(id: any){
    return this.httpClient.get(`${this.API}/${id}`);
  }

  salvarEvento(dados: Partial<any>){
    return this.httpClient.post(this.API, dados);
   }

  deleteById(id: any){
    return this.httpClient.delete(`${this.API}/${id}`);
  }

  editarEvento(dados: Partial<any>){
    return this.httpClient.put(`${this.API}/${dados['id']}`, dados);
  }

  filtro(dados: Partial<any>){
    return this.httpClient.post(`${this.API}/filtro`, dados);
   }

  filtroAreas(dados: Partial<any>){
    return this.httpClient.post(`${this.API}/filtro-areas`, dados);
   }

  salvarArea(dados: Partial<any>){
    return this.httpClient.post(`${this.API}/salvar-area`, dados);
  }

   deleteAreaById(id: any){
    return this.httpClient.delete(`${this.API}/area/${id}`);
  }

  editarArea(dados: Partial<any>){
    return this.httpClient.put(`${this.API}/area/${dados['id']}`, dados);
  }


}
