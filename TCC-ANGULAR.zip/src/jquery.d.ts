declare interface JQuery {
  modal(action: 'show' | 'hide' | 'toggle'): this;
}
