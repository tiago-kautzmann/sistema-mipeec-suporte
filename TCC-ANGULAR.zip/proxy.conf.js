const PROXY_CONFIG = [
  {
    context: ['/api'],
    // target: 'http://localhost:8080/',
    target: 'http://localhost:8080/ProjetoSpring-0.0.1-SNAPSHOT/',
    secure: false,
    logLevel: 'debug'
  }
];

module.exports = PROXY_CONFIG;
